#include<GL/glut.h>
#include<stdlib.h>
#include<stdio.h>
int x1,x2,y1,y2;

void putpixel(int x, int y,float r,float g,float b)
{
    glColor3f(r,g,b); 
    glBegin(GL_POINTS);
    glVertex2i(x,y);
    glEnd();
}

void rgbcall(int Xin,int Yin)
{
    putpixel(Xin,Yin,0.5,0.1,0.5);
    putpixel(Xin,Yin+1,1.0,1.0,1.0);
    putpixel(Xin,Yin+2,0.1,0.1,0.7);
    putpixel(Xin,Yin+3,0.1,0.6,0.1);
    putpixel(Xin,Yin+4,1.0,1.0,0.3);
    putpixel(Xin,Yin+5,1.0,0.5,0.1);
    putpixel(Xin,Yin+6,0.9,0.1,0.0);
}

void slopGreterThanOne(int dx,int dy)
{
    int  Xin=x1;
    int  Yin=y1;
    int p=dx-(dy/2);
//rgbcall
    rgbcall(Xin,Yin);
// putpixel(x,y);
    while(Yin<y2)
    {
        Yin++;
        if(p<0)
            p=p+dx;
        else
        {
            p=p+(dx-dy);
            Xin++;  
        }
        printf("(%d, %d) \n",Xin,Yin);
        rgbcall(Xin,Yin);
    }
}

void slopLessThatOne(int dx,int dy)
{
    int  Xin=x1;
    int  Yin=y1;
    int p=dy-(dx/2);
    rgbcall(Xin,Yin);
    while(Xin<x2)
    {
        Xin++;
        if(p<0)
            p=p+dy;
        else
        {
            p=p+(dy-dx);
            Yin++;
        }
        printf("(%d, %d) \n",Xin,Yin);
        rgbcall(Xin,Yin);
    }
}
void display(void)
{
    int dy,dx,Xin,Yin,p;
    dx=x2-x1;
    dy=y2-y1;
    printf("slop is %d\n",dy/dx);
    if((dy/dx)>1)
        slopGreterThanOne(dx,dy);
    else
    {
        slopLessThatOne(dx,dy);
    }
    glFlush();
}

void init(void)
{
    glMatrixMode(GL_PROJECTION);    
    glPointSize(10);
// glutSetColor(1,0.1,1.5,0.5);
    glLoadIdentity();
    gluOrtho2D(-100,100,-100,100);

}
int main(int argc, char** argv) 
{
    printf("Enter the value of x1 : ");
    scanf("%d",&x1);
    printf("Enter the value of y1 : ");
    scanf("%d",&y1);
    printf("Enter the value of x2 : ");
    scanf("%d",&x2);
    printf("Enter the value of y2 : ");
    scanf("%d",&y2);
    glutInit(&argc, argv);
    glutInitDisplayMode (GLUT_SINGLE | GLUT_RGBA);
    glutInitWindowSize (1000, 1000);
    glutInitWindowPosition (100,100);
    glutCreateWindow ("Bresenham Mid-Line Algo with VIBGYOR color ");
    init();
    glutDisplayFunc(display);
    glutMainLoop();
    return 0;
}
