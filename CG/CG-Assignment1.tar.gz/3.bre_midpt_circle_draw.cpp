
#include<stdio.h>
#include<GL/gl.h>
#include<GL/glu.h>
#include<GL/glut.h>

int x_c1,y_c1,rad;
int first=0;
int xi,yi,xf,yf;
void putPixel(int x,int y)
{
	if(x>0 && y>0)
	{
	glColor3f(1.0,1.0,0.0);
	glPointSize (5);
	}
	if(x>0 && y<0)
	{
	glColor3f(0.0,0.0,1.0);
        glPointSize (5);
	}
	if(x<0 && y>0)
	{
	glColor3f(0.0,1.0,0.0);
        glPointSize (5);
	}
	if(x<0 && y<0)
	{
	glColor3f(1.0,1.0,1.0);
        glPointSize (5);
	}
	glBegin(GL_POINTS);
	glVertex2i(x,y);
	glEnd();
	glFlush();
}

void bresen_circle(int x0,int y0,int radius)
{    int x = radius;
    int y = 0;
    int err = 0;
 
    while (x >= y)
    {
	putPixel(x0 + x, y0 + y);
	putPixel(x0 + y, y0 + x);
	putPixel(x0 - y, y0 + x);
	putPixel(x0 - x, y0 + y);
	putPixel(x0 - x, y0 - y);
	putPixel(x0 - y, y0 - x);
	putPixel(x0 + y, y0 - x);
	putPixel(x0 + x, y0 - y);
 
	if (err <= 0)
	{
	    y += 1;
	    err += 2*y + 1;
	}
 
	if (err > 0)
	{
	    x -= 1;
	    err -= 2*x + 1;
	}
    }
}


void display()
{
	glClearColor(1.0,1.0,1.0,1.0);
     glColor3f(1.5,0.6,0.6);
//        glPointSize (5);
	glClear(GL_COLOR_BUFFER_BIT);

//	int x1=100,y1=100,x2=300,y2=300;
//	for(int i=0;i<4;i++)
//	{
//	scanf("%d%d%d%d",&a,&b,&c,&d);	
	bresen_circle(x_c1,y_c1,rad);
//	x1+=30;
//	x2+=30;
//	}	
	glFlush();
}
void myinit()
{
	glViewport(0,0,640,480);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(0.0,640.0,0.0,480.0);
	glMatrixMode(GL_MODELVIEW);
}

int main(int argc,char **argv)
{
	printf("Enter coordinates of origin (x1,y1):");
	scanf("%d %d",&x_c1,&y_c1);
	printf("Enter radius");
	scanf("%d",&rad);
	glutInit(&argc,argv);
	glutInitDisplayMode(GLUT_SINGLE|GLUT_RGB);
	glutInitWindowSize(1024,640);
	glutCreateWindow("Bresenham Line Algorithm");
	glutDisplayFunc(display);
	myinit();
	glutMainLoop();
	return 0;
}

