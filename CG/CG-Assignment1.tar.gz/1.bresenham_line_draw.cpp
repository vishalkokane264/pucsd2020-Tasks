
#include<stdio.h>
#include<GL/gl.h>
#include<GL/glu.h>
#include<GL/glut.h>
#include<math.h>

int x_c1,y_c1,x_c2,y_c2;
int first=0;
int xi,yi,xf,yf;
void putPixel(int x,int y)
{
	if(x>=0 && y>0)
	{
	glColor3f(1.0,1.0,0.0);
	glPointSize (5);
	}
	if(x>=0 && y<0)
	{
	glColor3f(0.0,0.0,1.0);
        glPointSize (10);
	}
	if(x<0 && y>=0)
	{
	glColor3f(0.0,1.0,0.0);
        glPointSize (5);
	}
	if(x<0 && y<=0)
	{
	glColor3f(1.0,1.0,1.0);
        glPointSize (10);
	}
	glBegin(GL_POINTS);
	glVertex2i(x,y);
	glEnd();
	glFlush();
}

void bresenham(int x0,int y0,int x1,int y1)
{
//	int x0=50,y0=50,x1=400,y1=400;
	int dx=abs(x1-x0);
	int dy=abs(y1-y0);
	int x,y;
	if(dx>=dy)
	{
		int d=2*dy-dx;
		int ds=2*dy;
		int dt=2*(dy-dx);
		if(x0 < x1)
		{
			x=x0;
			y=y0;
		}
		else
		{
			x=xi;
			y=yi;
			x1=x0;
			y1=y0;
		}
		putPixel(x,y);
		while(x < x1)
		{
			if(d < 0)
				d=d+ds;
			else
			{
				if(y<y1)
				{
					y++;
					d=d+dt;
				}
				else
				{
					y--;
					d=d+dt;
				}
			}
			x++;
			putPixel(x,y);
		}
	}
	else
	{
		int d=2*dx-dy;
		int ds=2*dx;
		int dt=2*(dx-dy);
		if(y0 < y1)
		{
			x=x0;
			y=y0;
		}
		else
		{
			x=x1;
			y=y1;
			y1=y0;
			x1=x0;
		}
		putPixel(x,y);
		while(y<y1)
		{
			if(d<0)
				d=d+ds;
			else
			{
				if(x > x1)
				{
					x--;
					d=d+dt;
				}
				else
				{
					x++;
					d=d+dt;
				}
			}
			y++;
			putPixel(x,y);
		}
	}

}
void printquadrant(int x1,int y1)
{
	if(x1>0 && y1>0)
	printf("First quadrant\n");
	if(x1>0 && y1<0)
	printf("fourth quadrant\n");
	if(x1<0 && y1>0)
	printf("Second quadrant\n");
	if(x1<0 && y1<0)
	printf("Third quadrant\n");
	else
	printf("Point on the origin\n");
	
	
}

void display()
{
	glClearColor(1.0,1.0,1.0,1.0);
     glColor3f(1.5,0.6,0.6);
//        glPointSize (5);
	glClear(GL_COLOR_BUFFER_BIT);

//	int x1=100,y1=100,x2=300,y2=300;
//	for(int i=0;i<4;i++)
//	{
//	scanf("%d%d%d%d",&a,&b,&c,&d);	
	bresenham(x_c1,y_c1,x_c2,y_c2);
//	x1+=30;
//	x2+=30;
//	}	
	glFlush();
}
void myinit()
{
	glViewport(0,0,640,480);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(-480.0,640.0,-640.0,480.0);
	glMatrixMode(GL_MODELVIEW);
}

int main(int argc,char **argv)
{
	printf("Enter coordinates(x1,y1):");
	scanf("%d %d",&x_c1,&y_c1);
	printquadrant(x_c1,y_c1);
	printf("Enter coordinates(x2,y2):");
	scanf("%d %d",&x_c2,&y_c2);
	printquadrant(x_c2,y_c2);
	glutInit(&argc,argv);
	glutInitDisplayMode(GLUT_SINGLE|GLUT_RGB);
	glutInitWindowSize(1024,640);
	glutCreateWindow("Bresenham Line Algorithm");
	glutDisplayFunc(display);
	myinit();
	glutMainLoop();
	return 0;
}
